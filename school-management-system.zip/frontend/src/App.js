
import React from 'react';
import StudentForm from './components/StudentForm';
import Dashboard from './components/Dashboard';

function App() {
  return (
    <div>
      <h1>School Management System</h1>
      <StudentForm />
      <Dashboard />
    </div>
  );
}

export default App;
