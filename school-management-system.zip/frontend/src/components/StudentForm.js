
import React, { useState } from 'react';
import axios from 'axios';

function StudentForm() {
  const [student, setStudent] = useState({
    name: '',
    dob: '',
    class_id: '',
    parent_contact: ''
  });

  const handleChange = e => setStudent({...student, [e.target.name]: e.target.value});

  const handleSubmit = async e => {
    e.preventDefault();
    await axios.post('http://localhost:5000/api/students', student);
    alert('Student Added');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" placeholder="Name" onChange={handleChange} />
      <input name="dob" type="date" onChange={handleChange} />
      <input name="class_id" placeholder="Class ID" onChange={handleChange} />
      <input name="parent_contact" placeholder="Parent Contact" onChange={handleChange} />
      <button type="submit">Add Student</button>
    </form>
  );
}

export default StudentForm;
