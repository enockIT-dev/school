# School Management System

A simple full‑stack application for managing students, teachers, classes, attendance, fees, exams, and more.  
This project is split into two parts:

- **backend/** – Node.js/Express API with Mongoose models.
- **frontend/** – Vite‑powered React application for administrators, teachers, and parents.

> ⚠️ Note: the React project lives in `frontend/frontend` due to the way it was initialized.

## 🚀 Getting Started

### Prerequisites

- Node.js (v14+ recommended)
- npm or yarn
- MongoDB (local or Atlas)

---

## 📁 Project Structure

```
school-management-system/
│
├── backend/
│   ├── models/         # Mongoose schemas (Student, Teacher, Class, ...)
│   ├── routes/         # Express routers
│   ├── controllers/    # Request handlers
│   ├── middleware/     # Auth, logging, etc.
│   ├── app.js          # Express app config
│   └── server.js       # Entry point
│
├── frontend/          # root folder for the React project
│   └── frontend/      # actual Vite/React project
│       ├── public/
│       ├── src/
│       │   ├── components/ # Reusable UI pieces
│       │   ├── pages/      # Dashboard views
│       │   ├── App.jsx
│       │   └── main.jsx
│       └── package.json
│
└── README.md
```

---

## 🛠️ Backend Setup

1. Enter the backend directory:

   ```bash
   cd backend
   ```

2. Install dependencies (already done):

   ```bash
   npm install express mongoose cors dotenv
   ```

3. Create a `.env` file with your MongoDB URI:

   ```
   MONGO_URI=mongodb://localhost:27017/school-db
   PORT=5000
   ```

4. Start the server:

   ```bash
   node server.js
   ```

   The API will listen on `http://localhost:5000`.

5. Models, routes and controllers for the major entities are scaffoled (students, teachers, classes, subjects, attendance, fees, exams, grades, library, transport).

---

## 🎨 Frontend Setup

1. Navigate into the React project (note the nested folder):

   ```bash
   cd frontend/frontend
   ```

2. Install dependencies:

   ```bash
   npm install
   ```

3. Start the development server:

   ```bash
   npm run dev
   ```

   Visit `http://localhost:5173` (default Vite port) to view the app.

4. Pages and components mirror backend entities.  The `AdminDashboard` component lets you add and browse records for every model.

---

## � Authentication & Users

The system now supports user registration and login.  Each account has a `role` field that can be `student`, `teacher`, `parent` or `admin`.

- Register via `POST /api/auth/register` or use the frontend **Register** page.  A corresponding `Student` or `Teacher` record is created automatically for those roles.
- Login via `POST /api/auth/login` or the **Login** page; the response returns a JWT which is stored in `localStorage`.
- Protected routes (creating records) require the authorization header `Bearer <token>`. The frontend `api` helper handles this automatically.
- Middleware lives in `backend/middleware/auth.js` and can be applied to any route.

Existing documentation above explains the backend and frontend setup as usual.

---

## 📝 Contributing / Extending

- Add more fields/validation to schemas as needed.
- You can restrict certain actions based on `req.user.role` in controllers.
- Deploy using Heroku/Netlify/Vercel or your preferred provider; be sure to point `MONGO_URI` to production database.

---

Happy coding! 🎓🔧
