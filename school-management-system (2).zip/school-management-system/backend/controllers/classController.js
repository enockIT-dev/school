const Class = require('../models/Class');

exports.getClasses = async (req, res) => {
    const classes = await Class.find();
    res.json(classes);
};

exports.addClass = async (req, res) => {
    const cls = new Class(req.body);
    await cls.save();
    res.json(cls);
};
