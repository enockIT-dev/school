const Transport = require('../models/Transport');

exports.getTransports = async (req, res) => {
    const list = await Transport.find();
    res.json(list);
};

exports.addTransport = async (req, res) => {
    const t = new Transport(req.body);
    await t.save();
    res.json(t);
};
