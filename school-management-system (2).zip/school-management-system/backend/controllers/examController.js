const Exam = require('../models/Exam');

exports.getExams = async (req, res) => {
    const exams = await Exam.find();
    res.json(exams);
};

exports.addExam = async (req, res) => {
    const exam = new Exam(req.body);
    await exam.save();
    res.json(exam);
};
