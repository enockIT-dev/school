const Teacher = require('../models/Teacher');

exports.getTeachers = async (req, res) => {
    const teachers = await Teacher.find();
    res.json(teachers);
};

exports.addTeacher = async (req, res) => {
    const teacher = new Teacher(req.body);
    await teacher.save();
    res.json(teacher);
};
