const Library = require('../models/Library');

exports.getLibraries = async (req, res) => {
    const libs = await Library.find();
    res.json(libs);
};

exports.addLibrary = async (req, res) => {
    const lib = new Library(req.body);
    await lib.save();
    res.json(lib);
};
