const Attendance = require('../models/Attendance');

exports.getAttendances = async (req, res) => {
    const list = await Attendance.find();
    res.json(list);
};

exports.addAttendance = async (req, res) => {
    const att = new Attendance(req.body);
    await att.save();
    res.json(att);
};
