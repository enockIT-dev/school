const Subject = require('../models/Subject');

exports.getSubjects = async (req, res) => {
    const subjects = await Subject.find();
    res.json(subjects);
};

exports.addSubject = async (req, res) => {
    const sub = new Subject(req.body);
    await sub.save();
    res.json(sub);
};
