const express = require('express');
const router = express.Router();
const controller = require('../controllers/classController');

const auth = require('../middleware/auth');

router.get('/', controller.getClasses);
router.post('/', auth, controller.addClass);

module.exports = router;
