const express = require('express');
const router = express.Router();
const controller = require('../controllers/gradeController');

const auth = require('../middleware/auth');

router.get('/', controller.getGrades);
router.post('/', auth, controller.addGrade);

module.exports = router;
