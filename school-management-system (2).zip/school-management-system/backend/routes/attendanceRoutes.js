const express = require('express');
const router = express.Router();
const controller = require('../controllers/attendanceController');

const auth = require('../middleware/auth');

router.get('/', controller.getAttendances);
router.post('/', auth, controller.addAttendance);

module.exports = router;
