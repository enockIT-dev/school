const express = require('express');
const router = express.Router();
const controller = require('../controllers/transportController');

const auth = require('../middleware/auth');

router.get('/', controller.getTransports);
router.post('/', auth, controller.addTransport);

module.exports = router;
