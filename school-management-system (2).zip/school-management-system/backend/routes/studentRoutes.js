
const express = require('express');
const router = express.Router();
const controller = require('../controllers/studentController');

const auth = require('../middleware/auth');

router.get('/', controller.getStudents);
router.post('/', auth, controller.addStudent);

module.exports = router;
