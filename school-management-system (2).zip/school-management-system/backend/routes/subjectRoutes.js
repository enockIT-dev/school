const express = require('express');
const router = express.Router();
const controller = require('../controllers/subjectController');

const auth = require('../middleware/auth');

router.get('/', controller.getSubjects);
router.post('/', auth, controller.addSubject);

module.exports = router;
