const express = require('express');
const router = express.Router();
const controller = require('../controllers/examController');

const auth = require('../middleware/auth');

router.get('/', controller.getExams);
router.post('/', auth, controller.addExam);

module.exports = router;
