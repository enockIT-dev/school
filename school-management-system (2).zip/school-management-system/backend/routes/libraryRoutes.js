const express = require('express');
const router = express.Router();
const controller = require('../controllers/libraryController');

const auth = require('../middleware/auth');

router.get('/', controller.getLibraries);
router.post('/', auth, controller.addLibrary);

module.exports = router;
