const express = require('express');
const router = express.Router();
const controller = require('../controllers/teacherController');

const auth = require('../middleware/auth');

router.get('/', controller.getTeachers);
router.post('/', auth, controller.addTeacher);

module.exports = router;
