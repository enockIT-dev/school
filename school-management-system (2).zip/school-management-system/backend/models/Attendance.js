const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema({
    student_id: String,
    date: { type: Date, default: Date.now },
    status: String // present or absent
});

module.exports = mongoose.model('Attendance', attendanceSchema);
