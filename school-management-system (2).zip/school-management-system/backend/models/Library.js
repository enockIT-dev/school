const mongoose = require('mongoose');

const librarySchema = new mongoose.Schema({
    book_title: String,
    author: String,
    isbn: String,
    available: { type: Boolean, default: true }
});

module.exports = mongoose.model('Library', librarySchema);
