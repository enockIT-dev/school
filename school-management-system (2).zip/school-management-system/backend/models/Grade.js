const mongoose = require('mongoose');

const gradeSchema = new mongoose.Schema({
    student_id: String,
    exam_id: String,
    score: Number
});

module.exports = mongoose.model('Grade', gradeSchema);
