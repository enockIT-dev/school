
const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
    name: String,
    dob: Date,
    class_id: String,
    parent_contact: String,
    enrollment_date: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Student', studentSchema);
