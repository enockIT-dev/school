const mongoose = require('mongoose');

const transportSchema = new mongoose.Schema({
    route_name: String,
    driver_name: String,
    capacity: Number
});

module.exports = mongoose.model('Transport', transportSchema);
