const mongoose = require('mongoose');

const classSchema = new mongoose.Schema({
    name: String,
    grade: String,
    teacher_id: String
});

module.exports = mongoose.model('Class', classSchema);
