const mongoose = require('mongoose');

const feeSchema = new mongoose.Schema({
    student_id: String,
    amount: Number,
    due_date: Date,
    paid: { type: Boolean, default: false }
});

module.exports = mongoose.model('Fee', feeSchema);
