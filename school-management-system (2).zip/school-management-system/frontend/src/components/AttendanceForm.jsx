import React, { useState } from 'react';
import api from '../utils/api';

function AttendanceForm() {
  const [att, setAtt] = useState({ student_id: '', date: '', status: '' });

  const handleChange = e => setAtt({ ...att, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    await api.post('/attendances', att);
    alert('Attendance recorded');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="student_id" placeholder="Student ID" onChange={handleChange} />
      <input name="date" type="date" onChange={handleChange} />
      <select name="status" onChange={handleChange}>
        <option value="">--status--</option>
        <option value="present">Present</option>
        <option value="absent">Absent</option>
      </select>
      <button type="submit">Record</button>
    </form>
  );
}

export default AttendanceForm;
