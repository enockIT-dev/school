import React, { useEffect, useState } from 'react';
import api from '../utils/api';

function SubjectList() {
  const [subjects, setSubjects] = useState([]);

  useEffect(() => {
    api.get('/subjects')
      .then(res => setSubjects(res.data));
  }, []);

  return (
    <div>
      <h3>Subjects</h3>
      <ul>
        {subjects.map(s => <li key={s._id}>{s.name} ({s.code})</li>)}
      </ul>
    </div>
  );
}

export default SubjectList;
