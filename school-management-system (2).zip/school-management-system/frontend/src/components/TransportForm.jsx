import React, { useState } from 'react';
import api from '../utils/api';

function TransportForm() {
  const [route, setRoute] = useState({ route_name: '', driver_name: '', capacity: '' });

  const handleChange = e => setRoute({ ...route, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    await api.post('/transports', route);
    alert('Transport route added');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="route_name" placeholder="Route" onChange={handleChange} />
      <input name="driver_name" placeholder="Driver" onChange={handleChange} />
      <input name="capacity" type="number" placeholder="Capacity" onChange={handleChange} />
      <button type="submit">Add Route</button>
    </form>
  );
}

export default TransportForm;
