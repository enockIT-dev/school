import React, { useEffect, useState } from 'react';
import api from '../utils/api';

function LibraryList() {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    api.get('/libraries')
      .then(res => setBooks(res.data));
  }, []);

  return (
    <div>
      <h3>Library</h3>
      <ul>
        {books.map(b => (
          <li key={b._id}>{b.book_title} by {b.author}</li>
        ))}
      </ul>
    </div>
  );
}

export default LibraryList;
