import React, { useEffect, useState } from 'react';
import api from '../utils/api';

function FeeList() {
  const [fees, setFees] = useState([]);

  useEffect(() => {
    api.get('/fees')
      .then(res => setFees(res.data));
  }, []);

  return (
    <div>
      <h3>Fees</h3>
      <ul>
        {fees.map(f => (
          <li key={f._id}>{f.student_id} - {f.amount} - Due {new Date(f.due_date).toLocaleDateString()}</li>
        ))}
      </ul>
    </div>
  );
}

export default FeeList;
