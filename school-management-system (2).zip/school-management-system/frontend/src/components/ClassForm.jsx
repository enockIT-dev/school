import React, { useState } from 'react';
import api from '../utils/api';

function ClassForm() {
  const [cls, setCls] = useState({ name: '', grade: '', teacher_id: '' });

  const handleChange = e => setCls({ ...cls, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    await api.post('/classes', cls);
    alert('Class added');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" placeholder="Class Name" onChange={handleChange} />
      <input name="grade" placeholder="Grade" onChange={handleChange} />
      <input name="teacher_id" placeholder="Teacher ID" onChange={handleChange} />
      <button type="submit">Add Class</button>
    </form>
  );
}

export default ClassForm;
