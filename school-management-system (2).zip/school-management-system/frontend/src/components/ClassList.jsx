import React, { useEffect, useState } from 'react';
import axios from 'axios';

function ClassList() {
  const [classes, setClasses] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/classes')
      .then(res => setClasses(res.data));
  }, []);

  return (
    <div>
      <h3>Classes</h3>
      <ul>
        {classes.map(c => <li key={c._id}>{c.name} (Grade {c.grade})</li>)}
      </ul>
    </div>
  );
}

export default ClassList;
