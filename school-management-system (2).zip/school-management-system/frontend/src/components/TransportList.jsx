import React, { useEffect, useState } from 'react';
import api from '../utils/api';

function TransportList() {
  const [routes, setRoutes] = useState([]);

  useEffect(() => {
    api.get('/transports')
      .then(res => setRoutes(res.data));
  }, []);

  return (
    <div>
      <h3>Transport</h3>
      <ul>
        {routes.map(r => (
          <li key={r._id}>{r.route_name} - Driver: {r.driver_name}</li>
        ))}
      </ul>
    </div>
  );
}

export default TransportList;
