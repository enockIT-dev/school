import React, { useEffect, useState } from 'react';
import api from '../utils/api';

function GradeList() {
  const [grades, setGrades] = useState([]);

  useEffect(() => {
    api.get('/grades')
      .then(res => setGrades(res.data));
  }, []);

  return (
    <div>
      <h3>Grades</h3>
      <ul>
        {grades.map(g => (
          <li key={g._id}>{g.student_id} - {g.score}</li>
        ))}
      </ul>
    </div>
  );
}

export default GradeList;
