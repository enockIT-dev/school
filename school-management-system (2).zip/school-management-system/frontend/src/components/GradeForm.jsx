import React, { useState } from 'react';
import api from '../utils/api';

function GradeForm() {
  const [grade, setGrade] = useState({ student_id: '', exam_id: '', score: '' });

  const handleChange = e => setGrade({ ...grade, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    await api.post('/grades', grade);
    alert('Grade recorded');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="student_id" placeholder="Student ID" onChange={handleChange} />
      <input name="exam_id" placeholder="Exam ID" onChange={handleChange} />
      <input name="score" type="number" placeholder="Score" onChange={handleChange} />
      <button type="submit">Add Grade</button>
    </form>
  );
}

export default GradeForm;
