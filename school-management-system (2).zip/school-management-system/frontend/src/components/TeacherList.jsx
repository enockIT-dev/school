import React, { useEffect, useState } from 'react';
import api from '../utils/api';

function TeacherList() {
  const [teachers, setTeachers] = useState([]);

  useEffect(() => {
    api.get('/teachers')
      .then(res => setTeachers(res.data));
  }, []);

  return (
    <div>
      <h3>Teachers</h3>
      <ul>
        {teachers.map(t => <li key={t._id}>{t.name}</li>)}
      </ul>
    </div>
  );
}

export default TeacherList;
