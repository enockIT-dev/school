import React, { useState } from 'react';
import api from '../utils/api';

function ExamForm() {
  const [exam, setExam] = useState({ name: '', date: '', class_id: '' });

  const handleChange = e => setExam({ ...exam, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    await api.post('/exams', exam);
    alert('Exam added');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" placeholder="Exam Name" onChange={handleChange} />
      <input name="date" type="date" onChange={handleChange} />
      <input name="class_id" placeholder="Class ID" onChange={handleChange} />
      <button type="submit">Add Exam</button>
    </form>
  );
}

export default ExamForm;
