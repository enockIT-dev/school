import React, { useState } from 'react';
import api from '../utils/api';

function TeacherForm() {
  const [teacher, setTeacher] = useState({ name: '', subject: '' });

  const handleChange = e => setTeacher({ ...teacher, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    await api.post('/teachers', teacher);
    alert('Teacher added');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" placeholder="Name" onChange={handleChange} />
      <input name="subject" placeholder="Subject" onChange={handleChange} />
      <button type="submit">Add Teacher</button>
    </form>
  );
}

export default TeacherForm;
