import React, { useEffect, useState } from 'react';
import api from '../utils/api';

function StudentList() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    api.get('/students')
      .then(res => setStudents(res.data));
  }, []);

  return (
    <div>
      <h3>Students</h3>
      <ul>
        {students.map(s => <li key={s._id}>{s.name}</li>)}
      </ul>
    </div>
  );
}

export default StudentList;
