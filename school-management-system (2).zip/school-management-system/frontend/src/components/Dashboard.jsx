
import React, { useEffect, useState } from 'react';
import api from '../utils/api';

function Dashboard() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    api.get('/students')
      .then(res => setStudents(res.data));
  }, []);

  return (
    <div>
      <h2>Student List</h2>
      <ul>
        {students.map(s => (
          <li key={s._id}>{s.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default Dashboard;
