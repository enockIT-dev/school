import React, { useState } from 'react';
import api from '../utils/api';

function FeeForm() {
  const [fee, setFee] = useState({ student_id: '', amount: '', due_date: '' });

  const handleChange = e => setFee({ ...fee, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    await api.post('/fees', fee);
    alert('Fee created');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="student_id" placeholder="Student ID" onChange={handleChange} />
      <input name="amount" type="number" placeholder="Amount" onChange={handleChange} />
      <input name="due_date" type="date" onChange={handleChange} />
      <button type="submit">Add Fee</button>
    </form>
  );
}

export default FeeForm;
