import React, { useEffect, useState } from 'react';
import api from '../utils/api';

function ExamList() {
  const [exams, setExams] = useState([]);

  useEffect(() => {
    api.get('/exams')
      .then(res => setExams(res.data));
  }, []);

  return (
    <div>
      <h3>Exams</h3>
      <ul>
        {exams.map(e => (
          <li key={e._id}>{e.name} - {new Date(e.date).toLocaleDateString()}</li>
        ))}
      </ul>
    </div>
  );
}

export default ExamList;
