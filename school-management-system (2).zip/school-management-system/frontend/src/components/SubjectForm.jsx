import React, { useState } from 'react';
import api from '../utils/api';

function SubjectForm() {
  const [subject, setSubject] = useState({ name: '', code: '' });

  const handleChange = e => setSubject({ ...subject, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    await api.post('/subjects', subject);
    alert('Subject added');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" placeholder="Subject Name" onChange={handleChange} />
      <input name="code" placeholder="Code" onChange={handleChange} />
      <button type="submit">Add Subject</button>
    </form>
  );
}

export default SubjectForm;
