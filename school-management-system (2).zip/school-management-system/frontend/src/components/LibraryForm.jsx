import React, { useState } from 'react';
import api from '../utils/api';

function LibraryForm() {
  const [book, setBook] = useState({ book_title: '', author: '', isbn: '' });

  const handleChange = e => setBook({ ...book, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    await api.post('/libraries', book);
    alert('Book added');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="book_title" placeholder="Title" onChange={handleChange} />
      <input name="author" placeholder="Author" onChange={handleChange} />
      <input name="isbn" placeholder="ISBN" onChange={handleChange} />
      <button type="submit">Add Book</button>
    </form>
  );
}

export default LibraryForm;
