import React, { useEffect, useState } from 'react';
import api from '../utils/api';

function AttendanceList() {
  const [records, setRecords] = useState([]);

  useEffect(() => {
    api.get('/attendances')
      .then(res => setRecords(res.data));
  }, []);

  return (
    <div>
      <h3>Attendance</h3>
      <ul>
        {records.map(r => (
          <li key={r._id}>{r.student_id} - {new Date(r.date).toLocaleDateString()} - {r.status}</li>
        ))}
      </ul>
    </div>
  );
}

export default AttendanceList;
