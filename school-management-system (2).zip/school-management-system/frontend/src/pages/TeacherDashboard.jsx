import React, { useEffect, useState } from 'react';
import api from '../utils/api';

function TeacherDashboard() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    api.get('/students')
      .then(res => setStudents(res.data));
  }, []);

  return (
    <div>
      <h2>Teacher Dashboard</h2>
      <h3>Student List</h3>
      <ul>
        {students.map(s => (
          <li key={s._id}>{s.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default TeacherDashboard;
