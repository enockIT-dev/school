import React from 'react';
import StudentForm from '../components/StudentForm';
import TeacherForm from '../components/TeacherForm';
import ClassForm from '../components/ClassForm';
import StudentList from '../components/StudentList';
import TeacherList from '../components/TeacherList';
import ClassList from '../components/ClassList';
import SubjectForm from '../components/SubjectForm';
import SubjectList from '../components/SubjectList';
import AttendanceForm from '../components/AttendanceForm';
import AttendanceList from '../components/AttendanceList';
import FeeForm from '../components/FeeForm';
import FeeList from '../components/FeeList';
import ExamForm from '../components/ExamForm';
import ExamList from '../components/ExamList';
import GradeForm from '../components/GradeForm';
import GradeList from '../components/GradeList';
import LibraryForm from '../components/LibraryForm';
import LibraryList from '../components/LibraryList';
import TransportForm from '../components/TransportForm';
import TransportList from '../components/TransportList';
import { Link } from 'react-router-dom';

function AdminDashboard() {
  return (
    <div>
      <h2>Admin Dashboard</h2>
      <nav>
        <Link to="/admin/students">Students</Link> |{' '}
        <Link to="/admin/teachers">Teachers</Link> |{' '}
        <Link to="/admin/classes">Classes</Link>
      </nav>
      <section>
        <h3>Add Entities</h3>
        <StudentForm />
        <TeacherForm />
        <ClassForm />
        <SubjectForm />
        <AttendanceForm />
        <FeeForm />
        <ExamForm />
        <GradeForm />
        <LibraryForm />
        <TransportForm />
      </section>
      <section>
        <h3>Existing Records</h3>
        <StudentList />
        <TeacherList />
        <ClassList />
        <SubjectList />
        <AttendanceList />
        <FeeList />
        <ExamList />
        <GradeList />
        <LibraryList />
        <TransportList />
      </section>
    </div>
  );
}

export default AdminDashboard;
