import React from 'react';

function ParentDashboard() {
  return (
    <div>
      <h2>Parent Dashboard</h2>
      <p>Welcome, parent! Here you can view your child's progress and attendance.</p>
    </div>
  );
}

export default ParentDashboard;
