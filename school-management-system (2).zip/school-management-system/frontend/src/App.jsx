import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import AdminDashboard from './pages/AdminDashboard';
import TeacherDashboard from './pages/TeacherDashboard';
import ParentDashboard from './pages/ParentDashboard';
import Dashboard from './components/Dashboard';
import StudentList from './components/StudentList';
import TeacherList from './components/TeacherList';
import ClassList from './components/ClassList';
import Login from './pages/Login';
import Register from './pages/Register';
import { getUser, removeToken } from './utils/auth';
import { useState } from 'react';
import './App.css';

function App() {
  const [user, setUser] = useState(getUser());
  const handleLogout = () => {
    removeToken();
    setUser(null);
  };

  return (
    <Router>
      <header>
        <nav>
          <Link to="/">Home</Link> |
          {user ? (
            <>
              <span> Welcome, {user.role} </span> |
              <button onClick={handleLogout}>Logout</button> |
            </>
          ) : (
            <>
              <Link to="/login">Login</Link> |
              <Link to="/register">Register</Link> |
            </>
          )}
          <Link to="/admin">Admin</Link> |
          <Link to="/teacher">Teacher</Link> |
          <Link to="/parent">Parent</Link>
        </nav>
      </header>

      <main>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/students" element={<StudentList />} />
          <Route path="/admin/teachers" element={<TeacherList />} />
          <Route path="/admin/classes" element={<ClassList />} />
          <Route path="/teacher" element={<TeacherDashboard />} />
          <Route path="/parent" element={<ParentDashboard />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        </Routes>
      </main>
    </Router>
  );
}

export default App;
